export const COLORS = {
  background: '#F9F9FB',
  primaryText: '#4A148C',
  logoText: '#6A1B1B',
  secondaryText: '#666',
  cardBg: '#FFFDF9',
  cardBorder: '#CBB8EE',
  star: '#FFD700',
  white: '#FFFFFF',
  purpleBtn: '#4A148C',
  gradientStart: '#E8C5B0',
  gradientEnd: '#6A1B1B',
};